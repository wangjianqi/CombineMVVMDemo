//
//  DrugCellViewModel.swift
//  RxSwiftMVVMDemo
//
//  Created by wujuan on 2019/7/25.
//  Copyright © 2019 guahao. All rights reserved.
//

import Foundation
import Combine

@available(iOS 13.0, *)
class DrugCellViewModel: NSObject {
    
    var drugModel: DrugModel
//    var drugCount: Int
    
    private let editHeadingPublisher: PassthroughSubject<DrugCellViewModel, Never>
    var editPublisher: AnyPublisher<DrugCellViewModel, Never>

    private let deleteHeadingPublisher: PassthroughSubject<DrugCellViewModel, Never>
    var deletePublisher: AnyPublisher<DrugCellViewModel, Never>

    
    init(drugModel:DrugModel) {
        self.drugModel = drugModel
//        drugCount = drugModel.drugCount
        
        editHeadingPublisher = PassthroughSubject<DrugCellViewModel, Never>()
        editPublisher = editHeadingPublisher.eraseToAnyPublisher()
        
        deleteHeadingPublisher = PassthroughSubject<DrugCellViewModel, Never>()
        deletePublisher = deleteHeadingPublisher.eraseToAnyPublisher()
    }
    
    func addDrug() {
        self.drugModel.drugCount += 1
        
//        drugCount+=1
        editHeadingPublisher.send(self)
    }

    func minusDrug() {
        if drugModel.drugCount > 0 {
//            drugCount-=1
            self.drugModel.drugCount -= 1
            editHeadingPublisher.send(self)
        }
    }

    func deleteDrug(){
        deleteHeadingPublisher.send(self)
    }
}

